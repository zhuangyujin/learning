package zyj.com.test;

import zyj.com.spring.BeanPostProcessor;
import zyj.com.spring.Component;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

//实现接口告诉框架怎么初始化bean
@Component
public class testBeanPostProcessor implements BeanPostProcessor {
    @Override
    public Object postProcessBeforeInitialization(String beanName, Object bean) {
        //如果bean是userService
        if (beanName.equals("userService"))
        {
            //所作的处理
            System.out.println("userService所作的处理");
        }
        //将处理后的bean返回
        return bean;
    }

    @Override
    public Object postProcessAfterinitialization(String beanName, Object bean) {
        if (beanName.equals("userService"))
        {
            //AOP,声明AOP操作后返回proxyInstance，只有调用方法时候用AOP方法
            //类加载器，类所实现的接口
            Object proxyInstance = Proxy.newProxyInstance(testBeanPostProcessor.class.getClassLoader(), bean.getClass().getInterfaces(), new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                    //代理逻辑
                    System.out.println("切面逻辑");
                    return method.invoke(bean,args);
                }
            });
            //某些bean返回的是代理对象
            return proxyInstance;
        }
        return bean;
    }
}
