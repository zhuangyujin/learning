package zyj.com.test;

import zyj.com.spring.ComponentScan;

@ComponentScan("zyj.com.test")
public class Config {
}
