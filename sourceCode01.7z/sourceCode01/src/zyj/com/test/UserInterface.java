package zyj.com.test;

public interface UserInterface {
    public void test();
}
