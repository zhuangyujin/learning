package zyj.com.test;


import zyj.com.spring.ApplicationContext;



public class test {
    test a;
    public static void main(String[] args) {
        ApplicationContext applicationContext = new ApplicationContext(Config.class);
        UserInterface userService0 = (UserInterface) applicationContext.getBean("userService");
        //userService0.test();
        //userService0.testOrderService();
    }
}
