package zyj.com.test;

import zyj.com.spring.*;

@Component
@Scope("singleton")
public class UserService implements BeanNameAware, InitializingBean ,UserInterface{
    @Autowire
    private OrderService orderService;
    public void testOrderService()
    {
        System.out.println(orderService);
    }

    private String beanName;

    private String xxx;
    //这个方法是给spring调用的,将它想要的信息传给你
    @Override
    public void setBeanName(String beanName) {
        this.beanName =beanName;
    }

    //自己写，spring会调用
    @Override
    public void afterPropertiesSet() {

    }

    @Override
    public void test() {
        System.out.println("userService切面逻辑");
    }
}
