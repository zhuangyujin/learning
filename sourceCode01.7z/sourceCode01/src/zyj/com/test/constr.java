package zyj.com.test;

import java.lang.reflect.Constructor;

public class constr {
    constr(String a)
    {

    }
    public static void main(String[] args){
        try {
            constr.class.getConstructor(String.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}
