package zyj.com.test;

import zyj.com.spring.Component;

@Component
public class OrderService {
}
