package zyj.com.spring;

public interface BeanNameAware {
    public void setBeanName(String beanName);
}
