package zyj.com.spring;


                            //处理
public interface BeanPostProcessor {

    //bean之前初始化
    public Object postProcessBeforeInitialization(String beanName,Object bean);
   //bean之后初始化
    public Object postProcessAfterinitialization(String beanName,Object bean);
}
