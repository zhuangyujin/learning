package zyj.com.spring;

import java.beans.Introspector;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
/**
 * 扫描
 *
 */
public class ApplicationContext {
    private Class configClass;
    //并发的beanDefinition的map
    private ConcurrentHashMap<String,BeanDefinition> beanDefinitionMap =new ConcurrentHashMap<String, BeanDefinition>();
    //生成的bean
    private ConcurrentHashMap<String,Object> singletonObjects =new ConcurrentHashMap<String, Object>();
    //对实现了BeanPostProcessor接口的bean获取规则对所有符合规则的bean做处理
    private ArrayList<BeanPostProcessor> beanPostProcessorArrayList=new ArrayList<>();
    public ApplicationContext(Class configClass) {
        this.configClass=configClass;
        //如果配置类有全局扫描注解
        if (configClass.isAnnotationPresent(ComponentScan.class))
        {
            //获取全局扫描注解
            ComponentScan componentScanAnnotation = (ComponentScan) configClass.getAnnotation(ComponentScan.class);
            //获取包路径
            String path = componentScanAnnotation.value();
            //把包的.号换成/
            path=path.replace(".","/");
            //获取上下文的类加载器
            ClassLoader classLoader = ApplicationContext.class.getClassLoader();

            //获取资源，也就是com包
            URL resource = classLoader.getResource(path);

            String filePath = resource.getFile();

            //获取包的文件
            File file = new File(filePath);

            //如果是文件夹
            if (file.isDirectory())
            {
                //获取文件夹里所有的文件
                File[] files = file.listFiles();
                for (File f : files) {
                    String fileName = f.getAbsolutePath();
                    //如果是class文件
                    if (fileName.endsWith(".class"))
                    {
                        String className = fileName.substring(fileName.indexOf("zyj\\com\\test"), fileName.indexOf(".class"));
                        String s = className.replace("\\", ".");
                        try {
                            Class<?> clazz = classLoader.loadClass(s);
                            //有component注解生成BeanDefinition
                            if (clazz.isAnnotationPresent(Component.class))
                            {
                                //clazz实现或者继承这个class
                                if (BeanPostProcessor.class.isAssignableFrom(clazz))
                                {
                                    //创建对象
                                    BeanPostProcessor instance = (BeanPostProcessor) clazz.newInstance();
                                    //加到加工bean数组里面去
                                    beanPostProcessorArrayList.add(instance);
                                }

                                //获取组成名字
                                Component component = clazz.getAnnotation(Component.class);
                                String name = component.value();
                                //名字没有设置
                                if (name.equals(""))
                                {
                                    //将类名，开头小写
                                    name = Introspector.decapitalize(clazz.getSimpleName());
                                }
                                BeanDefinition beanDefinition = new BeanDefinition();
                                //如果有scope注解
                                if (clazz.isAnnotationPresent(Scope.class))
                                {
                                    Scope scopeAnnotation = clazz.getAnnotation(Scope.class);
                                    beanDefinition.setScope(scopeAnnotation.value());
                                }else
                                {
                                    beanDefinition.setScope("singleton");
                                }
                                //设置Class类型
                                beanDefinition.setType(clazz);

                                //存到map
                                beanDefinitionMap.put(name,beanDefinition);
                            }
                            
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        } catch (InstantiationException e) {
                            e.printStackTrace();
                        }
                    }
                }

                //先全盘扫描存进去beandefinition再存进bean
                //遍历map的key
                for (String beanName : beanDefinitionMap.keySet()) {
                    BeanDefinition beanDefinition = beanDefinitionMap.get(beanName);
                    //如果是单例
                    if (beanDefinition.getScope().equals("singleton"))
                    {
                        Object bean = createBean(beanName, beanDefinition);
                        //创建bean存在
                        singletonObjects.put(beanName,bean);
                    }
                }
            }
        }
    }

    //私有的创建一个bean对象
    private Object createBean(String beanName, BeanDefinition beanDefinition)
    {
        //获取bean定义里的Class类型
        Class type = beanDefinition.getType();
        //利用Class的构造方法创建对象
        try {
            Object bean = type.getConstructor().newInstance();
            //给加了autowire注解的属性赋值
            for (Field f:
                 type.getDeclaredFields()) {
                //当前属性就注解autowire
                if (f.isAnnotationPresent(Autowire.class))
                {
                    //设置属性可接触
                    f.setAccessible(true);
                    //将属性的名字放进去找bean
                    f.set(bean,getBean(f.getName()));
                }
            }
            //如果对象实现了某个接口或者是哪个类的子类
            //beanAware名字回调
            if (bean instanceof BeanNameAware)
            {
                //强转,将beanName告诉你
                ((BeanNameAware) bean).setBeanName(beanName);
            }
            //bean的前置处理
            for (BeanPostProcessor beanPostProcessor : beanPostProcessorArrayList) {
                bean = beanPostProcessor.postProcessBeforeInitialization(beanName,bean);
            }
            //初始化
            if (bean instanceof InitializingBean)
            {
                ((InitializingBean) bean).afterPropertiesSet();
            }

            //bean后置处理器AOP
            for (BeanPostProcessor beanPostProcessor : beanPostProcessorArrayList) {
                bean = beanPostProcessor.postProcessAfterinitialization(beanName,bean);
            }
            //放入单例池
            singletonObjects.put(beanName,bean);
            return bean;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Object  getBean(String beanName) {
        //根据beanName
        BeanDefinition beanDefinition = beanDefinitionMap.get(beanName);
        //找不到抛异常
        if (beanDefinition==null)
        {
            throw  new NullPointerException();
        }else
        {
            String scope = beanDefinition.getScope();
            //判断单例多例
            if (scope.equals("singleton"))
            {
                //从objects的map找到bean
                Object bean = singletonObjects.get(beanName);
                //如果找不到,就创建一下
                if (bean == null)
                {
                    bean = createBean(beanName, beanDefinition);
                    //存到objects的map
                    singletonObjects.put(beanName,bean);
                }
                return bean;
            }
            else
            {
                //不是单例则直接创建bean
                return createBean(beanName,beanDefinition);
            }
        }
    }
}
