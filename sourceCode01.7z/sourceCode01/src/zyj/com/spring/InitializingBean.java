package zyj.com.spring;

//初始化bean
public interface InitializingBean {
    //设置属性
    public void afterPropertiesSet();
}
